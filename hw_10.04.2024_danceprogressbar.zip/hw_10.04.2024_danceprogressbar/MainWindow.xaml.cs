﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;


namespace hw_10._04._2024_danceprogressbar
{
    public partial class MainWindow : Window
    {
        private ProgressBar[] progressBars;
        private Random random = new Random();
        private int numberOfProgressBars { get; set; }
        

        public MainWindow()
        {
            InitializeComponent();

            
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            numberOfProgressBars = Convert.ToInt32(CountProgressBars.Text);

            progressBars = new ProgressBar[numberOfProgressBars];
            int j = 200;
            for (int i = 0; i < numberOfProgressBars; i++)
            {
                if (i % 2 == 0)
                {
                    j += 220;
                }
                progressBars[i] = new ProgressBar
                {
                    Width = 200,
                    Height = 30,
                    Minimum = 0,
                    Maximum = 100,
                    Value = 0,
                    Foreground = new SolidColorBrush(Color.FromRgb((byte)random.Next(256), (byte)random.Next(256), (byte)random.Next(256))),
                    Margin = new Thickness(random.Next(100, 200), random.Next(100, 200), random.Next(100, 200), random.Next(100, 200)),
                    HorizontalAlignment = HorizontalAlignment.Left,
                    VerticalAlignment = VerticalAlignment.Top
                };
                this.MainGrid.Children.Add(progressBars[i]);
            }

            foreach (var progressBar in progressBars)
            {
                Task.Run(() => UpdateProgressBar(progressBar));
            }
        }

        private void UpdateProgressBar(ProgressBar progressBar)
        {
            for (int i = 0; i <= 100; i++)
            {
                Thread.Sleep(random.Next(100));
                this.Dispatcher.Invoke(() => progressBar.Value = i);
                this.Dispatcher.Invoke(() => progressBar.Margin = 
                new Thickness(random.Next(100, 200), random.Next(100, 200), random.Next(100, 200), random.Next(100, 200)));
            }
        }
    }
}