﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.WebRequestMethods;

namespace FinalProjectFilms
{
    public partial class MainWindow : Window
    {
        private bool _isEditMode;
        private ModelViewFilm ModelViewFilm;
        private int currentIdFilm = 1;
        public MainWindow()
        {
            InitializeComponent();
            SetFilm();
        }

        private void SetFilm()
        {
            var modelFilm = GetIdFilm(currentIdFilm);
            if (modelFilm != null)
            {
                ModelViewFilm = new ModelViewFilm(modelFilm);
                DataContext = ModelViewFilm;
            }
            else
            {
                MessageBox.Show("some error");
            }
        }

        private ModelFilm GetIdFilm(int id)
        {
            using (FilmsEntities db = new FilmsEntities())
            {
                var dbFilm = db.Movies.FirstOrDefault(m => m.ID == id);
                if (dbFilm != null)
                {
                    return new ModelFilm
                    {
                        Id = dbFilm.ID,
                    };
                }
            }
            return null;
        }

        private async Task UpdateCurrentFilmAsync()
        {
            using (var db = new FilmsEntities())
            {
                var movie = await Task.Run(() => db.Movies.FirstOrDefault(m => m.ID == ModelViewFilm.Film.Id));
                var director = await Task.Run(() => db.Directors.FirstOrDefault(d => d.ID == ModelViewFilm.Film.Id));
                var mainActor = await Task.Run(() => db.Actors.FirstOrDefault(a => a.ID == ModelViewFilm.Film.Id));

                if (movie != null)
                {
                    movie.Movie_Name = ModelViewFilm.Film.MovieName;
                    movie.Release_Year = ModelViewFilm.Film.DataRelease;
                    movie.Country = ModelViewFilm.Film.Country;
                    movie.Duration = ModelViewFilm.Film.Duration;
                    movie.Movie_Link = ModelViewFilm.Film.MovieLink;
                    mainActor.Actor_Name = ModelViewFilm.Film.MainActor;
                    director.Director_Name = ModelViewFilm.Film.Director;
                    movie.Rating = ModelViewFilm.Film.Rating;
                    movie.Description = ModelViewFilm.Film.Description;

                    await db.SaveChangesAsync();
                }
            }
            SetFilm();
        }

        private async void EditButton_Click(object sender, RoutedEventArgs e)
        {
            _isEditMode = !_isEditMode;
            ChangeEditMode(_isEditMode);
            if (!_isEditMode)
                await UpdateCurrentFilmAsync();
        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentIdFilm != 20)
                currentIdFilm++;
            else if (currentIdFilm == 20)
                currentIdFilm = 1;

            SetFilm();
        }
        private void PreviouslyButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentIdFilm != 1)
                currentIdFilm--;
            else if (currentIdFilm == 1)
                currentIdFilm = 20;

            SetFilm();
        }
        private void ChangeEditMode(bool isEditMode)
        {
            Thickness border = isEditMode ? new Thickness(1) : new Thickness(0);

            tb_MovieName.IsReadOnly = !isEditMode;
            tb_MovieName.BorderThickness = border;

            tb_DataRelease.IsReadOnly = !isEditMode;
            tb_DataRelease.BorderThickness = border;

            tb_Country.IsReadOnly = !isEditMode;
            tb_Country.BorderThickness = border;

            tb_Duration.IsReadOnly = !isEditMode;
            tb_Duration.BorderThickness = border;

            tb_MovieLink.IsReadOnly = !isEditMode;
            tb_MovieLink.BorderThickness = border;

            tb_MainActor.IsReadOnly = !isEditMode;
            tb_MainActor.BorderThickness = border;

            tb_Director.IsReadOnly = !isEditMode;
            tb_Director.BorderThickness = border;

            tb_Rating.IsReadOnly = !isEditMode;
            tb_Rating.BorderThickness = border;

            tb_Description.IsReadOnly = !isEditMode;
            tb_Description.BorderThickness = border;

        }
        private void LogInButton_Click(object sender, RoutedEventArgs e)
        {
            var loginWindow = new LoginWindow();
            var dialogResult = loginWindow.ShowDialog();
            bool flag = false;
            using (var db = new FilmsEntities())
            {
                List<Users> users = db.Users.ToList();
                foreach (var user in users)
                {
                    if (user.Login.Contains(loginWindow.LoginTextBox.Text))
                    {
                        flag = true;
                    }
                }
                if (flag)
                    MessageBox.Show("Успешный вход в систему!");
                else
                {
                    MessageBox.Show("Вход в систему не удался... \nПрограмма будет завершена.");
                    Application.Current.Shutdown();
                }
            }
        }

        private void SignInButton_Click(object sender, RoutedEventArgs e)
        {
            var registrationWindow = new RegistrationWindow();
            registrationWindow.ShowDialog();
        }
    }
}