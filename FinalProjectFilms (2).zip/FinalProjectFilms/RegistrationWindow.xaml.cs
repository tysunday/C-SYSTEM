﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalProjectFilms
{
    /// <summary>
    /// Логика взаимодействия для RegistrationWindow.xaml
    /// </summary>
    public partial class RegistrationWindow : Window
    {
        public RegistrationWindow()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new FilmsEntities())
            {
                var user = db.Users.FirstOrDefault(u => u.Login == LoginTextBox.Text);
                if (user == null)
                {
                    user = new Users
                    {
                        FirstName = FirstNameTextBox.Text,
                        LastName = LastNameTextBox.Text,
                        Phone = PhoneTextBox.Text,
                        Email = EmailTextBox.Text,
                        Login = LoginTextBox.Text,
                    };
                    db.Users.Add(user);
                    db.SaveChanges();
                    MessageBox.Show("Account created. You can now log in with your username.");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Username is already taken. Please try another one.");
                }
            }
        }
    }
}