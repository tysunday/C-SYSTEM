﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace FinalProjectFilms
{
    public partial class ModelFilm
    {
        public int Id { get; set; }
        public string MovieName { get; set; } = string.Empty;
        public int? DataRelease { get; set; }
        public string Country { get; set; } = string.Empty;
        public TimeSpan? Duration { get; set; }
        public string MovieLink { get; set; } = string.Empty;
        public string MainActor { get; set; } = string.Empty;
        public string Director { get; set; } = string.Empty;
        public Decimal? Rating { get; set; }
        public string Description { get; set; }
        public string ReviewComment { get; set; } = string.Empty; 
        public BitmapImage FilmImage { get; set; }

    }
}
