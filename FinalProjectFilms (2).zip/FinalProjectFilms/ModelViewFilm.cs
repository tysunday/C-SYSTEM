﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace FinalProjectFilms
{
    public class ModelViewFilm : INotifyPropertyChanged
    {
        public ModelFilm Film { get; private set; }
        private FilmsEntities FilmsEntities;

        public ModelViewFilm(ModelFilm film)
        {
            Film = film;
            FilmsEntities = new FilmsEntities();

            var movie = FilmsEntities.Movies.FirstOrDefault(m => m.ID == Film.Id);
            var director = FilmsEntities.Directors.FirstOrDefault(d => d.ID == Film.Id);
            var mainActor = FilmsEntities.Actors.FirstOrDefault(a => a.ID == Film.Id);
            var image = FilmsEntities.Images.FirstOrDefault(i => i.ID == Film.Id);
            if (movie != null)
            {
                Film.MovieName = movie.Movie_Name;
                Film.DataRelease = movie.Release_Year;
                Film.Country = movie.Country;
                Film.Duration = movie.Duration;
                Film.MovieLink = movie.Movie_Link;
                Film.Director = director.Director_Name;
                Film.MainActor = mainActor.Actor_Name;
                Film.Rating = movie.Rating;
                Film.Description = movie.Description;
                Film.FilmImage = ConvertToImage(image.ImageData);
            }
        }
        public BitmapImage ConvertToImage(byte[] array)
        {
            using (var ms = new System.IO.MemoryStream(array))
            {
                var image = new BitmapImage();
                image.BeginInit();
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.StreamSource = ms;
                image.EndInit();
                return image;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}