﻿using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace hw_13._04._2024_asyncreader
{
    internal class AsyncReader
    {
        FileStream _stream;
        byte[] _data;
        IAsyncResult _result;

        public bool IsCompleted
        {
            get { return _result.IsCompleted; }
        }

        public AsyncReader(FileStream fs, int size)
        {
            _stream = fs;
            _data = new byte[size];
            _result = fs.BeginRead(_data, 0, size, null, null);
        }

        public string EndRead()
        {
            int countByte = _stream.EndRead(_result);
            _stream.Close();
            Array.Resize(ref _data, countByte);
            return $">>>>>>>>>>>>>>>>>>>>>>>>>>Файл:>>>>>>>>>>>>>>>>>>>>>>>>>> {_stream.Name}\n{Encoding.UTF8.GetString(_data)}" +
                $">>>>>>>>>КОНЕЦ ФАЙЛА>>>>>>>>>";
        }
    }

    public partial class MainWindow : Window, INotifyPropertyChanged
    {

        public event PropertyChangedEventHandler PropertyChanged;

        void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
        }

        private List<string> _selectedPaths = new List<string>();
        public List<string> selectedPaths
        {
            get
            {
                return _selectedPaths;
            }
            set
            {
                _selectedPaths = value;
                NotifyPropertyChanged("selectedPaths");
            }
        }

        private void SelectFileButton_Click(object sender, RoutedEventArgs e)
        {
            selectedPaths.Clear();
            OpenFileDialog openFileDialog = new OpenFileDialog()
            {
                Multiselect = true,
            };
            if (openFileDialog.ShowDialog() == true)
            {
                selectedPaths.AddRange(openFileDialog.FileNames);
            }
            
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            TextsFromFile.Text = "";
        }

        private async void LearnTextButton_Click(object sender, RoutedEventArgs e)
        {
            if (selectedPaths == null || selectedPaths.Count == 0)
            {
                MessageBox.Show("No files selected");
                return;
            }

            foreach (string path in _selectedPaths)
            {
                try
                {
                    using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read))
                    {
                        AsyncReader reader = new AsyncReader(fs, (int)fs.Length);

                        while (!reader.IsCompleted)
                        {
                            await Task.Delay(100);
                        }

                        TextsFromFile.Text += reader.EndRead();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }
        private async void ReadAllButton_Click(object sender, RoutedEventArgs e)
        {
            foreach (DriveInfo drive in DriveInfo.GetDrives())
            {
                if (drive.IsReady)
                {
                    await SearchAndReadTxtFiles(drive.RootDirectory.FullName);
                }
            }
        }

        private async Task SearchAndReadTxtFiles(string startPath)
        {
            try
            {
                IEnumerable txtFilePaths = Directory.EnumerateFiles(startPath, "*.txt", SearchOption.AllDirectories);

                foreach (string path in txtFilePaths)
                {
                    using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read))
                    {
                        TextsFromFile.Text += $"<<<<<<<<<<<<<<<<<<< ПУТЬ К ФАЙЛУ: {path} <<<<<<<<<<<<<<<<<<<\n";

                        AsyncReader reader = new AsyncReader(fs, (int)fs.Length);

                        while (!reader.IsCompleted)
                        {
                            await Task.Delay(100);
                        }

                        TextsFromFile.Text += reader.EndRead() + "\n\n";
                    }
                }
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (PathTooLongException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
