﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using hw18042024LibrarySquare;

namespace hw18042024areamathsmethods
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(AreaMethods.SquareArea(5));
            Console.WriteLine(AreaMethods.TriangleArea(5,5));
            Console.WriteLine(AreaMethods.RectangleArea(5,5));
        }
    }
}
