﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using hw18042024LibrarySquare;
using AdditionStringLibrary;

namespace hw18042024areamathsmethods
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(AreaMethods.SquareArea(5));
            Console.WriteLine(AreaMethods.TriangleArea(5, 5));
            Console.WriteLine(AreaMethods.RectangleArea(5, 5));

            Console.WriteLine(AdditionString.IsPalindrome("woow"));
            Console.WriteLine(AdditionString.IsPalindrome("wow"));
            Console.WriteLine(AdditionString.IsPalindrome("w"));
            Console.WriteLine(AdditionString.IsPalindrome("wooq"));
            Console.WriteLine(AdditionString.IsPalindrome("qqoow"));
            Console.WriteLine(AdditionString.IsPalindrome("woqow"));

            Console.WriteLine(AdditionString.HowManyWords("привет как твои дела? ч е с №3ю4 а в"));
            Console.WriteLine(AdditionString.HowManySentences("helo my nema si vlad.slalv fdlldf;f. maybe u thik i'am crzy?"));

            Console.WriteLine(AdditionString.HowManySymbols("hello it's me"));
        }
    }
}
