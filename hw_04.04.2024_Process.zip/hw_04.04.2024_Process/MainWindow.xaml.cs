﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace hw_04._04._2024_Process
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Process myProcess;
        DateTime startTime;
        public MainWindow()
        {
            InitializeComponent();
            myProcess = new Process();
            myProcess.StartInfo = new ProcessStartInfo("hw_05.04.2024.exe");
            myProcess.EnableRaisingEvents = true;
            myProcess.Exited += MyProcess_Exited;
        }

        private void MyProcess_Exited(object sender, EventArgs e)
        {
            var runTime = DateTime.Now - startTime;
            Dispatcher.Invoke(() => 
            TimeInfo.Text = $"Time Process: {runTime.TotalSeconds} seconds");
        }

        private void Start_Click(object sender, RoutedEventArgs e)
        {
            startTime = DateTime.Now;
            myProcess.Start();
            DebugInfo.Text = "Name Process: " + myProcess.ProcessName +
                "\n" + "ID Process: " + myProcess.Id;
        }
        private void Stop_Click(object sender, RoutedEventArgs e)
        {
            if (!myProcess.HasExited)
            {
                myProcess.Kill();
            }
        }
    }
}
