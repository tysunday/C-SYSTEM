﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace hw_05._04._2024_startbaseapp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        static void StartNewProcess(Process process)
        {
            process.Start();
        }
        private void StartCalc_Click(object sender, RoutedEventArgs e)
        {
            Process CalcProcess = new Process();
            CalcProcess.StartInfo = new ProcessStartInfo("calc.exe");
            CalcProcess.Start();
        }
        private void StartPaint_Click(object sender, RoutedEventArgs e)
        {
            Process PaintProcess = new Process();
            PaintProcess.StartInfo = new ProcessStartInfo("mspaint.exe");
            PaintProcess.Start();
        }
        private void StartNotebook_Click(object sender, RoutedEventArgs e)
        {
            Process NotebookProcess = new Process();
            NotebookProcess.StartInfo = new ProcessStartInfo("Notepad.exe");
            NotebookProcess.Start();
        }
    }
}
